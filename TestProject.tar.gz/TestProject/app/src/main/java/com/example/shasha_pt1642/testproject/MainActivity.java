package com.example.shasha_pt1642.testproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    EditText firstNumber,secondNumber;
    TextView addResult;
    Button btnAdd,btnSub,btnMul,btnDiv;
    double num1,num2,res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //
        firstNumber=(EditText)findViewById(R.id.editText);
        secondNumber=(EditText)findViewById(R.id.editText2);
        addResult=(TextView)findViewById(R.id.textViewResult);
        btnAdd=(Button)findViewById(R.id.buttonAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1=Double.parseDouble(firstNumber.getText().toString());
                num2=Double.parseDouble(secondNumber.getText().toString());
                res=num1+num2;
                addResult.setText(Double.toString(res));
            }
        });
        //
        btnSub=(Button)findViewById(R.id.buttonSub);
        btnSub.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view){
            num1=Double.parseDouble(firstNumber.getText().toString());
            num2=Double.parseDouble(secondNumber.getText().toString());
            res=num1-num2;
            addResult.setText(Double.toString(res));
        }
        });

        btnMul=(Button)findViewById(R.id.buttonMul);
        btnMul.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                num1=Double.parseDouble(firstNumber.getText().toString());
                num2=Double.parseDouble(secondNumber.getText().toString());
                res=num1*num2;
                addResult.setText(Double.toString(res));
            }
        });
        btnDiv=(Button)findViewById(R.id.buttonDiv);
        btnDiv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                num1=Double.parseDouble(firstNumber.getText().toString());
                num2=Double.parseDouble(secondNumber.getText().toString());
                res=num1/num2;
                addResult.setText(Double.toString(res));
            }
        });


    }
}
