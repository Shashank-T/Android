package com.example.shasha_pt1642.test_sms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class AddRecipientsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_recipients);

        TextView textView=(TextView)findViewById(R.id.resultsuccesstextView);
        textView.setText("Success!!");
    }
}
