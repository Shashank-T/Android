package com.example.shasha_pt1642.test_sms;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button buttonAlert,buttonAdd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,Manifest.permission.SEND_SMS)){
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.SEND_SMS},1);
            }
            else{
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.SEND_SMS},1);
            }
        }
        else{

        }




        buttonAlert=(Button)findViewById(R.id.alertButton);
        buttonAdd=(Button)findViewById(R.id.addButton);

        buttonAlert.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                    sendSMSMessage();
            }


        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                addRCPTS();
                Intent intent=new Intent(MainActivity.this,AddRecipientsActivity.class);
                startActivity(intent);
            }
        });
    }



    public void onRequestPermissionsResut(int requestCode,String[] permissions,int[] grantResults){
        switch (requestCode){
            case 1:{
                if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    if(ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED){
                        Toast.makeText(this,"Permission Granted!!",Toast.LENGTH_SHORT).show();
                    }
                }
                    else{
                        Toast.makeText(this,"Permission NOT Granted!!",Toast.LENGTH_SHORT).show();
                    }
                return;
            }
        }
    }



    protected void sendSMSMessage(){
        String[] phoneNos = {"9600582997","9600582997","8760033722"};
        String message = "Hi, Testing Alert SMS";
        try {
            SmsManager smsManager = SmsManager.getDefault();
            for(String phoneNo:phoneNos){
                smsManager.sendTextMessage(phoneNo, null, message, null, null);
                String notify="SMS sent to "+phoneNo;
                Toast.makeText(MainActivity.this,notify,
                        Toast.LENGTH_LONG).show();//wait(1000);
            }

        } catch (Exception e) {
            Toast.makeText(MainActivity.this,
                    "SMS failed, please try again.",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
    /*protected void addRCPTS() {



    }*/
    }
    //}
//}
